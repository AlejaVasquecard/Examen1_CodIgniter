<div class="container">
	<h2>Bienvenido a nuestra agenda de citas</h2>
	<div class="row">
	<a class="btn btn-info" href="<?php echo site_url('agenda/form'); ?>"> Solicitar citas</a>
	</div>
	<br>
	<div class="row">
		<img class="img-fluid" src="https://adpunto.mx/root-blog/wp-content/uploads/2018/09/Cita-02.png" alt="citas">
	</div>
</div>
<br>
