<html>
<head>
	<title>Agenda</title>
	<meta name="viewport" content="width=device-width, user-scalable=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-info bg-info">
	<div class="container">
		<h2 style="color: white"> <a style="text-decoration: none; color: white" href="<?php echo site_url('pages/view'); ?>" >AGENDAS</a> </h2>
	</div>
</nav>

